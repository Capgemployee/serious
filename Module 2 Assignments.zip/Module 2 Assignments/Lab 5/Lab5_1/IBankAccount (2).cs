﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace Lab5_1
{
    interface IBankAccount
    {
        double GetBalance();
        void Deposit(double amount);
        bool Withdraw(double amount);
        bool Transfer(IBankAccount toAccount, double amount);
        ClassLibrary.BankAccount.BankAccountTypeEnum AccountType { get; set; }
    }
}
