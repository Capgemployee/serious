﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace Lab5_1
{
    class Program
    {
        static void Main(string[] args)
        {
         
            ICICI icici1 = new ICICI();
            ClassLibrary.BankAccount.BankAccountTypeEnum type = ClassLibrary.BankAccount.BankAccountTypeEnum.Saving;
            icici1.Deposit(50000);
                        

            ICICI icici2 = new ICICI();
            type = ClassLibrary.BankAccount.BankAccountTypeEnum.Current;
            icici2.Deposit(20000);

            Console.WriteLine("Saving account balance : "+icici1.GetBalance());
            Console.WriteLine("Current account balance : "+icici2.GetBalance());
          
            type = ClassLibrary.BankAccount.BankAccountTypeEnum.Saving;
            icici1.Withdraw(5000);

            type = ClassLibrary.BankAccount.BankAccountTypeEnum.Current;
            icici2.Deposit(5000);
            Console.WriteLine("Saving account balance after transfer : " + icici1.GetBalance());
            Console.WriteLine("Current account balance after transfer : " + icici2.GetBalance());

           
            Console.ReadKey();

        }
    }
}
