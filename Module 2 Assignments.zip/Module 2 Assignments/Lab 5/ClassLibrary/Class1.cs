﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class BankAccount
    {
        public enum BankAccountTypeEnum
        {
            Current = 1,
            Saving = 2
        }
    }
}
