﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace ContactSerialzationSOAPFormatter
{
    [Serializable]
    public class Contact
    {
        public long ContactNo { get; set; }
        public String ContactName { get; set; }
        public string cellNo { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n-----------------Serialization of Contact Class using SOAP Formatter---------\n");
            Console.WriteLine("\nEnter ContactNo: ");
            long Contact = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("\nEnter Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("\nEnter cell no: ");
            string cellno = Console.ReadLine();

            Contact con = new Contact() { ContactNo = Contact, ContactName = name, cellNo = cellno };
            FileStream fs = new FileStream("contactSerialize.txt", FileMode.Create, FileAccess.Write);
            SoapFormatter sf = new SoapFormatter();
            sf.Serialize(fs, con);
            fs.Close();



            FileStream fs1 = new FileStream("contactSerialize.txt", FileMode.Open, FileAccess.Read);
            SoapFormatter sf1 = new SoapFormatter();
            Contact anotherEmp = (Contact)sf1.Deserialize(fs1);
            fs1.Close();

            Console.WriteLine("\nContact no :" + anotherEmp.ContactNo);
            Console.WriteLine("\nContact Name :" + anotherEmp.ContactName);
            Console.WriteLine("\nCell No :" + anotherEmp.cellNo);
            Console.ReadKey();
        }
    }
}

