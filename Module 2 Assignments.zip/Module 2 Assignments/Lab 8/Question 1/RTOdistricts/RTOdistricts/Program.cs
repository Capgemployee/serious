﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace RTOdistricts
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable hs = new Hashtable();
            hs.Add("MH01", " Mumbai");
            hs.Add("MH04", " Thane");
            hs.Add("MH05", " Pune");
            hs.Add("MH06", " Kalyan");

            Console.WriteLine("The Record Searched :" + hs.Contains("MH06"));

            Console.WriteLine("The Record Searched :" + hs.Contains("MH07"));

            foreach (var elem in hs.Keys)
            {
                Console.WriteLine("\n RTO District Elements :" + elem + hs[elem].ToString());
            }

            Console.WriteLine("\nTotal count of Records " + hs.Count);

            hs.Remove("MH05");
            Console.WriteLine("\n------------------------------After Deletion of Record -------------------------\n");
            foreach (var elem in hs.Keys)
            {
                Console.WriteLine("\nRTO District Elements :" + elem + hs[elem].ToString());
            }
        }
    }
}