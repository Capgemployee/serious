﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImprovedArithmeticDelegate
{

        public class ArithmeticOperation
    {
        public void Add(int num1, int num2)
        {

            Console.WriteLine("Sum of {0} & {1} is {2}", num1, num2, num1 + num2);
        }
        public void Subtract(int num1, int num2)
        {
            Console.WriteLine("Difference of {0} & {1} is {2}", num1, num2, (num1 - num2));
        }
        public void Multiply(int num1, int num2)
        {
            Console.WriteLine("Product of {0} & {1} is {2}", num1, num2, (num1 * num2));
        }
        public void Divide(int num1, int num2)
        {
            Console.WriteLine("Diviion of {0} & {1} is {2}", num1, num2, (num1 / num2));
        }
        public void Max(int num1, int num2)
        {
            if (num1 > num2)
                Console.WriteLine("{0} is maximum", num1);
            else if (num1 < num2)
                Console.WriteLine("{0} is maximum", num2);
            else Console.WriteLine("{0} & {1} are equal ", num1, num2);

        }

        public void PerformArithmeticOperation(int num1, int num2, ArithmeticDelegate del)
        {
            del(num1, num2);
        }
    }
}
