﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArithmeticDelgateExample
{
    delegate void ArithmeticDelegate(int num1, int num2);
    public class ArithmeticOperation
    {
        public void Add(int num1, int num2)
        {

            Console.WriteLine("Sum of {0} & {1} is {2}", num1, num2, num1 + num2);
        }
        public void Subtract(int num1, int num2)
        {
            Console.WriteLine("Difference of {0} & {1} is {2}", num1, num2, (num1 - num2));
        }
        public void Multiply(int num1, int num2)
        {
            Console.WriteLine("Product of {0} & {1} is {2}", num1, num2, (num1 * num2));
        }
        public void Divide(int num1, int num2)
        {
            Console.WriteLine("Diviion of {0} & {1} is {2}", num1, num2, (num1 / num2));
        }
        public void Max(int num1, int num2)
        {
            if (num1 > num2)
                Console.WriteLine("{0} is maximum", num1);
            else if (num1 < num2)
                Console.WriteLine("{0} is maximum", num2);
            else Console.WriteLine("{0} & {1} are equal ", num1, num2);

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            ArithmeticOperation obj = new ArithmeticOperation();


            Console.WriteLine("Enter num1 :");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter num2 :");
            int num2 = Convert.ToInt32(Console.ReadLine());


            char ch;
            do
            {
                Console.WriteLine("Enter Your Choice");
                Console.WriteLine("\n+: Add \n-: Subtract \n*:Multiply\n/:Divide\nM:Max Number");
                char choice = Convert.ToChar(Console.ReadLine());
                switch (choice)
                {
                    case '+': ArithmeticDelegate del = new ArithmeticDelegate(obj.Add);

                        del(num1, num2);
                        break;
                    case '-': ArithmeticDelegate del1 = new ArithmeticDelegate(obj.Subtract);
                        del1(num1, num2);
                        break;
                    case '*': ArithmeticDelegate del2 = new ArithmeticDelegate(obj.Multiply);
                        del2(num1, num2);
                        break;
                    case '/': ArithmeticDelegate del3 = new ArithmeticDelegate(obj.Divide);
                        del3(num1, num2);
                        break;
                    case 'M': ArithmeticDelegate del4 = new ArithmeticDelegate(obj.Max);

                        del4(num1, num2);
                        break;
                    default: Console.WriteLine("Please enter a valid operation");
                        break;
                }
                Console.WriteLine("Do you want to continue");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch == 'y' || ch == 'Y');

        }
    }
}
