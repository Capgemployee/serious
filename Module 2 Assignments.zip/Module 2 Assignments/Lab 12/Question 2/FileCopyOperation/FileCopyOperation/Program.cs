﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileCopyOperation
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                Console.WriteLine("Enter First File Name:");
                string file1 = Console.ReadLine();
                
                FileInfo fi1 = new FileInfo(file1);
                if (!fi1.Exists)
                {
                    throw new FileNotFoundException("First File not found");
                }

                Console.WriteLine("Enter Second File Name:");
                string file2 = Console.ReadLine();
                FileInfo fi2 = new FileInfo(file2);
               
                if (!fi2.Exists)
                {
                    throw new FileNotFoundException("Second File not Found");
                }

                FileStream fs1 = new FileStream(file1, FileMode.Open, FileAccess.Read);
                FileStream fs2 = new FileStream(file2, FileMode.Open, FileAccess.Write);


                fs1.CopyTo(fs2);
                fs1.Close();
                fs2.Close();
            }
            catch (FileNotFoundException ex)
            {
              Console.WriteLine(ex);
            }
           

                   
                

        }
    }
}
