﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CorporateProjectLibrary
{
    public class Participant
    {
        int EmpId;
        string EmpName;
        static string CompName;
        double FoundnMarks, WBMarks, DNMarks, ObtainedMarks, Percentage;
        double TotMarks = 300;
        public int EmployeeID
        {
            get { return EmpId; }
            set { EmpId = value; }
        }

        public string EmployeeName
        {
            get { return EmpName; }
            set { EmpName = value; }
        }

        public string CompanyName
        {
            get { return CompName; }
            set { CompName = value; }
        }

        public double FoundationMarks
        {
            get { return FoundnMarks; }
            set { FoundnMarks = value; }
        }

        public double WebBasicMarks
        {
            get { return WBMarks; }
            set { WBMarks = value; }
        }

        public double DotNetMarks
        {
            get { return DNMarks; }
            set { DNMarks = value; }
        }

        public Participant()
        {
           
        }

        public Participant(int eId, string eName, string cName, double FMarks, double wMarks, double dMarks)
        {
            EmpId = eId;
            EmpName = eName;
            CompName = cName;
            FoundnMarks = FMarks;
            WBMarks = wMarks;
            DNMarks = dMarks;
           
        }

        static Participant()
        {
            CompName = "Corporate Project";
            Console.WriteLine(CompName);
        }
        public double TotalObtainedMarks()
        {
            return this.ObtainedMarks = this.FoundnMarks + this.WBMarks + this.DNMarks;
        }
        public double PercentCalculate()
        {
            return Percentage = ObtainedMarks / TotMarks * 100;

        }

        public void PercentDisp()
        {
            Console.WriteLine("Percentage: {0}%", Percentage);
        }
    }
}
