﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EmployeeDetailsConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            int ch;
            Console.WriteLine("----------------------Employee Details-----------------------------");
            do
            {

                Console.WriteLine("\n1:Contract Employee\n2:Permanent Employee\n3Exit\n");

                Console.WriteLine("\n\nSelect Type of Employee:");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        ContractEmployee obj1 = new ContractEmployee();
                        obj1.EmployeeID();
                        obj1.EmployeeName();
                        obj1.EmpAddress();
                        obj1.EmpCity();
                        obj1.EmpDept();
                        obj1.GetSalary();
                        obj1.EmpPerks = 1200;
                        Console.WriteLine("Perks:" + obj1.Perks);            
                        break;

                    case 2:
                        PermanentEmployee obj2 = new PermanentEmployee();
                        obj2.EmployeeID();
                        obj2.EmployeeName();
                        obj2.EmpAddress();
                        obj2.EmpCity();
                        obj2.EmpDept();
                        obj2.GetSalary();
                        obj2.EmpLeaves = 24;
                        obj2.ProvidentFund = 1200;
                        Console.WriteLine("Total No of Leaves:" + obj2.EmpLeaves);
                        Console.WriteLine("Provident Fund:" + obj2.ProvidentFund);
                       
                        break;

                    case 3:
                        break;
                }
            } while (ch != 4);
                  
        }
    }
}
