﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchCaseConstruct
{
    class Program
    {
        static void Main(string[] args)
        {
            Program obj = new Program();
            int ch, value;
        

            Console.WriteLine("------------------------Switch Case Construct------------------------\n");
         
           

            do
            {
                Console.WriteLine("\n1.Press 1\n2.Press 2\n3.Press 3\n4.Press 4\n5.Press 5\n");
                Console.WriteLine("Enter Your Choice\n");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        
                        Console.WriteLine("You have entered 1\n");
                        break;

                    case 2:
                        Console.WriteLine("You have entered 2\n");
                        break;
                    case 3:
                        Console.WriteLine("You have entered 3\n");
                        break;

                    case 4:
                        Console.WriteLine("You have entered 4\n");
                        break;

                    case 5:
                        Console.WriteLine("You have entered 5\n");
                        break;
                    case 6:
                        Console.WriteLine("Error Message\n");
                            break;

                    default:
                        break;
                }
            } while (ch != 7);


            Console.ReadKey();
        }
    }
}
