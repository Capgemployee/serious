﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecords
{
  
    class Program
    {

        struct SchoolDemo
        {
            public int rollNumber;
            public string studentName;
            public int age;
            public string gender;
            public DateTime dob;
            public string address;
            public float percentage;
        };
        static void Main(string[] args)
        {
            
      SchoolDemo Student;   /* Declare Student of type SchoolDemo */
      
      /* Student specification */
      Student.rollNumber = 12;
      Student.studentName = "Raj Mehta";
      Student.age = 22;
      Student.gender = "Male";
      DateTime dob = new DateTime(1994, 12, 06);
      Student.address = "Mumbai";
      Student.percentage = 85.45f;

           
    
      /* print Student info */
      Console.WriteLine("Student Roll No :"+Student.rollNumber);
      Console.WriteLine("Student Name :"+Student.studentName);
      Console.WriteLine("Student Age :"+Student.age);
      Console.WriteLine("Student Gender :"+Student.gender);
      Console.WriteLine("Student Date of Birth :"+dob);
      Console.WriteLine("Student Address :"+Student.address);
      Console.WriteLine("Student Percentage :"+Student.percentage);

      Console.ReadKey();

        }
    }
}
