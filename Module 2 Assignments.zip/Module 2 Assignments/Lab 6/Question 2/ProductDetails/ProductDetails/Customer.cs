﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDetails
{
    public class Customer
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public double Price { get; set; }

        public Customer()
        {
        }
        public Customer(int CustomerId, string CustomerName, string Address, string City, long Phone, double CreditLimit)
        {
            this.ProductId = CustomerId;
            this.ProductName = ProductName;
            this.Price = Price;
        }
    }
}